#include "mem.h"

/** getBlock **/
/* Get block from "listNdx" free list */
blockNode *getBlock(int listNdx) {
   blockNode *allocPtr;    /* Pointer to allocated block           */

   /* Now allocate first block off of list */
   allocPtr = (void *)freeList[listNdx].next;
   if (allocPtr == NULL) {
     /* List is currently empty */
     return(NULL);
   }
 
   /* Remove block from free list */
   freeList[listNdx].next =  freeList[listNdx].next->next;

   /* Update number of allocated blocks in superblock */
   return(allocPtr);
} /* End getBlock */


/** freeBlock **/
/* Link freed block back onto head of appropriate free list */
void freeBlock(blockNode *freeBlockPtr, int listNdx) {

   /* Link block back into appropriate free list */
   ((blockNode *)freeBlockPtr)->next = freeList[listNdx].next;
   freeList[listNdx].next = (blockNode *)freeBlockPtr;

} /* End freeBlock */


/** splitBlock **/
/* Create a linked list of free blocks out of a larger block */
void splitBlock(int listNdx, blockNode *blockStart, int superBlockSize) {
    int       subBlockSize;    /* Size of sub-block     */
    blockNode *subBlock;       /* Pointer to sub-block  */
    blockNode *nextSubBlock;   /* Pointer to next block */
    int numBlocks;             /* Number of sub-blocks  */
    int blockCount;            /* loop counter          */

    subBlockSize = 1024 >> listNdx;
    assert(subBlockSize <= 1024);;
    /* Determine number of sub-blocks to create */
    numBlocks = superBlockSize/subBlockSize;
    blockCount=1;
    subBlock = blockStart;

    /* Create a linked list of sub-blocks in the super block */
    while (blockCount < numBlocks) {
       /* Computer address of next sub-block */
       nextSubBlock = (void *)subBlock + subBlockSize;
       /* Link it to list */
       subBlock->next = nextSubBlock;
       /* Move on to next block */
       subBlock = nextSubBlock;
       blockCount++;
    }
    subBlock->next = NULL;
    freeList[listNdx].next = blockStart;
    return;
} /* End splitBlock */
