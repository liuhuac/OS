
#include "vmsim.h"

/** pageFault **/
/*  Process page fault */
int pageFault(unsigned logicalAddress) {
    int pageNumber = logicalAddress >> 10;

    /** STUBBED -- just do random placement/replacement
    
        This is an implementation of random replacement.  The drand48()
        function returns a "random" value between 0 and 1.

        No attempt to do "placement" is done in this version.  An empty
        frame is only allocated if the random number generates the index
        of an empty frame (valid == 0).

        Also this stubbed version always returns the code for replacing
        a "dirty" page -- even though the replaced page may have been
        modified.
    
    ***/

    int frameNdx = drand48()*numPageFrames; /*Generate a random page frame # */

    /* Assign the page to this page frame */
    pageTable[frameNdx].vmPage = pageNumber;
    pageTable[frameNdx].valid = 1;

    /* Always return code for a "dirty" page */
    return(2);
}
